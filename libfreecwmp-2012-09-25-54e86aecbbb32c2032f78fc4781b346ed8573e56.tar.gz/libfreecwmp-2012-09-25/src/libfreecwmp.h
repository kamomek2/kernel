/*
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	Copyright (C) 2011-2012 Luka Perkov <freecwmp@lukaperkov.net>
 */

#ifndef _LIBFREECWMP_H__
#define _LIBFREECWMP_H__

#define ARRAY_SIZE(x) (sizeof(x) / sizeof(x[0]))

enum {
	L_CRIT,
	L_WARNING,
	L_NOTICE,
	L_INFO,
	L_DEBUG
};

enum {
	BOOTSTRAP = 0,
	BOOT,
	PERIODIC,
	SCHEDULED,
	VALUE_CHANGE,
	KICKED,
	CONNECTION_REQUEST,
	TRANSFER_COMPLETE,
	DIAGNOSTICS_COMPLETE,
	REQUEST_DOWNLOAD,
	AUTONOMOUS_TRANSFER_COMPLETE
};

void freecwmp_log_message(char *name, int priority, const char *format, ...);

char * freecwmp_str_event_code(int code);
int freecwmp_int_event_code(char *code);

#endif
