/*
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	Copyright (C) 2011-2012 Luka Perkov <freecwmp@lukaperkov.net>
 */

#include <stdarg.h>
#include <syslog.h>

#include "libfreecwmp.h"

static const int log_class[] = {
	[L_CRIT] = LOG_CRIT,
	[L_WARNING] = LOG_WARNING,
	[L_NOTICE] = LOG_NOTICE,
	[L_INFO] = LOG_INFO,
	[L_DEBUG] = LOG_DEBUG
};

void freecwmp_log_message(char *name, int priority, const char *format, ...)
{
	va_list vl;

	openlog(name, 0, LOG_DAEMON);

	va_start(vl, format);
	vsyslog(log_class[priority], format, vl);
	va_end(vl);

	closelog();
}

char * freecwmp_str_event_code(int code)
{
	switch (code) {
		case BOOT:
			return "1 BOOT";
		case PERIODIC:
			return "2 PERIODIC";
		case SCHEDULED:
			return "3 SCHEDULED";
		case VALUE_CHANGE:
			return "4 VALUE CHANGE";
		case CONNECTION_REQUEST:
			return "6 CONNECTION REQUEST";
		case BOOTSTRAP:
		default:
			break;
	}
	return "0 BOOTSTRAP";
}

int freecwmp_int_event_code(char *code)
{
	if (!strcasecmp("boot\0", code) ||
	    !strcasecmp("1 boot\0", code))
		return BOOT;

	if (!strcasecmp("periodic\0", code) ||
	    !strcasecmp("2 periodic\0", code))
		return PERIODIC;

	if (!strcasecmp("scheduled\0", code) ||
	    !strcasecmp("3 scheduled\0", code))
		return SCHEDULED;

	if (!strcasecmp("value change\0", code) ||
	    !strcasecmp("value_change\0", code) ||
	    !strcasecmp("4 value change\0", code))
		return VALUE_CHANGE;

	if (!strcasecmp("connection request\0", code) ||
	    !strcasecmp("connection_request\0", code) ||
	    !strcasecmp("6 connection request\0", code))
		return CONNECTION_REQUEST;

	return BOOTSTRAP;
}
